// netlify/functions/crear-firma-payu.mjs
// Genera la firma y los datos necesarios para abrir el checkout de PayU
// (WebCheckout). PayU muestra en su propia página TODOS los métodos
// habilitados en la cuenta: Botón Bancolombia, Nequi, Daviplata, PSE,
// tarjeta, efectivo, etc. No hace falta programar un botón por banco.
//
// Requiere estas variables de entorno en Netlify
// (Site configuration → Environment variables):
//   PAYU_MERCHANT_ID  → tu Merchant ID
//   PAYU_ACCOUNT_ID   → tu Account ID (Colombia)
//   PAYU_API_KEY      → tu API Key
//   PAYU_TEST         → "1" mientras pruebas en sandbox, "0" en producción
//
// El front-end recibe estos campos y los usa para armar un <form> real
// que se envía por POST al checkout de PayU (redirección, no es un link
// simple como el de Bold).

import crypto from "node:crypto";

const json = (data, status = 200) => Response.json(data, { status });

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Método no permitido" }, 405);

  const { PAYU_MERCHANT_ID, PAYU_ACCOUNT_ID, PAYU_API_KEY, PAYU_TEST } = process.env;
  if (!PAYU_MERCHANT_ID || !PAYU_ACCOUNT_ID || !PAYU_API_KEY) {
    return json({ error: "Faltan configurar PAYU_MERCHANT_ID, PAYU_ACCOUNT_ID y PAYU_API_KEY en Netlify" }, 500);
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "JSON inválido" }, 400);
  }

  const total = Math.round(Number(body?.total));
  if (!Number.isFinite(total) || total < 1000 || total > 20000000) {
    return json({ error: "Total inválido" }, 400);
  }
  const descripcion = String(body?.descripcion || "Pedido MF Colombia").slice(0, 100);
  const buyerEmail = String(body?.buyerEmail || "ventas@marlonfootwear.co").slice(0, 255);

  // Referencia única por pedido (para rastrear el pago en el panel de PayU)
  const referenceCode = "MF-" + Date.now();

  // Colombia: si no se envía el IVA, PayU lo calcula solo con 19%.
  // Lo calculamos aquí para mandarlo explícito.
  const amount = total;
  const taxReturnBase = Math.round((amount / 1.19) * 100) / 100;
  const tax = Math.round((amount - taxReturnBase) * 100) / 100;

  const isTest = PAYU_TEST === "1";
  const rawSignature = `${PAYU_API_KEY}~${PAYU_MERCHANT_ID}~${referenceCode}~${amount}~COP`;
  const signature = crypto.createHash("md5").update(rawSignature).digest("hex");

  return json({
    url: isTest
      ? "https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu/"
      : "https://checkout.payulatam.com/ppp-web-gateway-payu/",
    fields: {
      merchantId: PAYU_MERCHANT_ID,
      accountId: PAYU_ACCOUNT_ID,
      description: descripcion,
      referenceCode,
      amount: String(amount),
      tax: String(tax),
      taxReturnBase: String(taxReturnBase),
      currency: "COP",
      signature,
      test: isTest ? "1" : "0",
      buyerEmail,
    },
  });
};
